#default['mysql-component']['priveleges']=''
#if ( node['mysql-component']['priveleges'].empty? )
#  set['mysql-component']['priveleges']=nil
#end
